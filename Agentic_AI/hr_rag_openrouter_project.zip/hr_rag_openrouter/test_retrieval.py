"""
Optional small test for the retrieval part.

Run:
    python test_retrieval.py

This does NOT call OpenRouter. It only tests PDF extraction,
chunking, embeddings, and FAISS retrieval.
"""

from pathlib import Path

from app import extract_text_from_pdf, split_text, build_faiss_index, retrieve_chunks

pdf_path = Path("data/hr_policy.pdf")

text = extract_text_from_pdf(pdf_path)
chunks = split_text(text)
index = build_faiss_index(chunks)

question = "How many days of annual leave are employees entitled to?"

results = retrieve_chunks(question, chunks, index, top_k=3)

for result in results:
    print("=" * 80)
    print("Similarity:", result["score"])
    print(result["chunk"])
