import os
from pathlib import Path

import faiss
import numpy as np
import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer


# ---------------------------------------------------------
# 1. Configuration
# ---------------------------------------------------------

load_dotenv()

API_KEY = os.getenv("OPENROUTER_API_KEY")
MODEL_NAME = os.getenv("OPENROUTER_MODEL", "openrouter/free")

EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"

DATA_DIR = Path("data")
INDEX_DIR = Path("faiss_index")

DATA_DIR.mkdir(exist_ok=True)
INDEX_DIR.mkdir(exist_ok=True)

st.set_page_config(
    page_title="HR Policy RAG",
    page_icon="📄",
    layout="wide",
)


# ---------------------------------------------------------
# 2. Helper functions
# ---------------------------------------------------------

@st.cache_resource
def load_embedding_model():
    """Load the local embedding model only once."""
    return SentenceTransformer(EMBEDDING_MODEL_NAME)


def extract_text_from_pdf(pdf_path):
    """Read all text from a PDF."""
    reader = PdfReader(pdf_path)

    pages = []

    for page in reader.pages:
        text = page.extract_text() or ""
        pages.append(text)

    return "\n".join(pages)


def split_text(text, chunk_size=800, overlap=150):
    """
    Simple character-based chunking.

    Example:
    chunk 1 = characters 0-800
    chunk 2 = characters 650-1450
    ...
    """
    text = " ".join(text.split())

    chunks = []

    start = 0

    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        start += chunk_size - overlap

    return chunks


def build_faiss_index(chunks):
    """Create embeddings and store them in a FAISS index."""

    model = load_embedding_model()

    embeddings = model.encode(
        chunks,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )

    embeddings = embeddings.astype("float32")

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatIP(dimension)

    index.add(embeddings)

    return index


def retrieve_chunks(question, chunks, index, top_k=3):
    """Retrieve the most similar chunks for a question."""

    model = load_embedding_model()

    question_embedding = model.encode(
        [question],
        convert_to_numpy=True,
        normalize_embeddings=True,
    ).astype("float32")

    scores, indices = index.search(
        question_embedding,
        min(top_k, len(chunks)),
    )

    results = []

    for score, idx in zip(scores[0], indices[0]):
        if idx != -1:
            results.append(
                {
                    "chunk": chunks[idx],
                    "score": float(score),
                    "index": int(idx),
                }
            )

    return results


def ask_openrouter(question, retrieved_chunks):
    """Send retrieved context + question to OpenRouter."""

    if not API_KEY:
        raise ValueError(
            "OPENROUTER_API_KEY is missing. "
            "Create a .env file and add your OpenRouter API key."
        )

    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=API_KEY,
    )

    context = "\n\n".join(
        [
            f"[Source Chunk {i + 1}]\n{item['chunk']}"
            for i, item in enumerate(retrieved_chunks)
        ]
    )

    prompt = f"""
You are an HR policy assistant.

Answer the user's question using ONLY the HR document context below.

Rules:
1. Do not invent information.
2. If the answer is not present in the context, say:
   "I could not find this information in the HR document."
3. Keep the answer clear and concise.
4. If useful, mention the relevant policy or section.
5. Do not use outside knowledge.

HR DOCUMENT CONTEXT:
{context}

USER QUESTION:
{question}
"""

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {
                "role": "system",
                "content": "You answer questions using retrieved HR document context.",
            },
            {
                "role": "user",
                "content": prompt,
            },
        ],
        temperature=0.1,
    )

    return response.choices[0].message.content


# ---------------------------------------------------------
# 3. Streamlit UI
# ---------------------------------------------------------

st.title("📄 Basic HR Policy RAG Chatbot")

st.write(
    "Upload an HR policy PDF, build the vector index, and ask questions "
    "about the document."
)

if not API_KEY:
    st.warning(
        "OpenRouter API key not found. Add OPENROUTER_API_KEY to your .env file."
    )

uploaded_file = st.file_uploader(
    "Upload HR Policy PDF",
    type=["pdf"],
)

if uploaded_file:
    pdf_path = DATA_DIR / uploaded_file.name

    with open(pdf_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    st.success(f"Uploaded: {uploaded_file.name}")

    if st.button("🔨 Build / Rebuild Index"):

        with st.spinner("Reading PDF..."):
            text = extract_text_from_pdf(pdf_path)

        if not text.strip():
            st.error(
                "No readable text was found in this PDF. "
                "Try a text-based PDF rather than a scanned image PDF."
            )
            st.stop()

        with st.spinner("Splitting document into chunks..."):
            chunks = split_text(text)

        with st.spinner("Creating embeddings and FAISS index..."):
            index = build_faiss_index(chunks)

        st.session_state["chunks"] = chunks
        st.session_state["index"] = index

        st.success(
            f"Index created successfully. "
            f"Number of chunks: {len(chunks)}"
        )

# ---------------------------------------------------------
# 4. Question answering
# ---------------------------------------------------------

if "index" in st.session_state:

    st.divider()

    st.subheader("Ask a question")

    question = st.text_input(
        "Example: What is the maternity leave policy?"
    )

    top_k = st.slider(
        "Number of chunks to retrieve",
        min_value=1,
        max_value=5,
        value=3,
    )

    if st.button("🔎 Ask HR"):

        if not question.strip():
            st.warning("Please enter a question.")
            st.stop()

        with st.spinner("Searching the HR document..."):

            results = retrieve_chunks(
                question,
                st.session_state["chunks"],
                st.session_state["index"],
                top_k=top_k,
            )

        st.subheader("Retrieved Context")

        for i, result in enumerate(results):

            with st.expander(
                f"Chunk {i + 1} | Similarity: {result['score']:.3f}"
            ):
                st.write(result["chunk"])

        with st.spinner("Generating answer using OpenRouter..."):

            try:
                answer = ask_openrouter(
                    question,
                    results,
                )

                st.subheader("🤖 Answer")

                st.write(answer)

            except Exception as e:
                st.error(f"OpenRouter error: {e}")

else:

    st.info(
        "Upload an HR PDF and click 'Build / Rebuild Index' to start."
    )


st.divider()

st.caption(
    f"Embedding model: {EMBEDDING_MODEL_NAME} | "
    f"LLM: {MODEL_NAME} | "
    "Vector store: FAISS"
)
