Put your HR policy PDF files in this folder.

The application also lets you upload a PDF directly from the Streamlit UI.

Recommended beginner test questions for the supplied sample document:

1. What is the annual leave entitlement?
2. What is the maternity leave policy?
3. How many days of paternity leave are provided?
4. What is the work-from-home policy?
5. What is the notice period?
6. How long is the probation period?
