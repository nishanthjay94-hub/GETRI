# Basic HR Document RAG with OpenRouter

A beginner-friendly Retrieval-Augmented Generation (RAG) project.

## What this project does

1. Takes an HR policy PDF as input.
2. Extracts text from the PDF.
3. Splits the text into smaller chunks.
4. Creates embeddings using a local Sentence Transformer model.
5. Stores embeddings in a FAISS vector index.
6. Takes a user's question.
7. Retrieves the most relevant chunks.
8. Sends only the retrieved context + question to an LLM through OpenRouter.
9. Displays the answer and the retrieved source chunks.

## Architecture

HR PDF
  |
  v
PDF Text Extraction
  |
  v
Text Chunking
  |
  v
Sentence Transformer Embeddings
  |
  v
FAISS Vector Store
  |
  v
User Question
  |
  v
Question Embedding
  |
  v
Top-K Relevant Chunks
  |
  v
OpenRouter LLM
  |
  v
Answer

## Requirements

- Python 3.10 or 3.11 recommended
- Internet connection for the first embedding-model download and OpenRouter API calls
- OpenRouter API key

## Installation

### Windows

Create a virtual environment:

```bash
python -m venv venv
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Create a `.env` file from `.env.example` and add your OpenRouter key:

```text
OPENROUTER_API_KEY=your_key_here
```

Do NOT share your real API key or commit `.env` to Git.

## Run

```bash
streamlit run app.py
```

Open the URL shown by Streamlit, normally:

```text
http://localhost:8501
```

Upload `data/hr_policy.pdf` and click **Build / Rebuild Index**.

Then ask questions such as:

- How many days of annual leave are employees entitled to?
- What is the maternity leave policy?
- What is the work-from-home policy?
- How many days can an employee work remotely?
- What is the probation period?
- What is the notice period?

## Important beginner concept

This is RAG, not simply "send the PDF to the LLM".

The application first searches the HR document for relevant information. Only the retrieved text is placed into the LLM prompt.

This reduces the need to send the complete document on every question and makes the answer grounded in the retrieved document.

## Main files

- `app.py` - complete Streamlit RAG application
- `requirements.txt` - Python packages
- `.env.example` - API key template
- `data/hr_policy.pdf` - sample HR document
- `data/README.txt` - explains where to put another PDF

## Simple teaching flow

For a classroom demo, explain these 7 steps:

1. Load PDF
2. Split text
3. Create embeddings
4. Store embeddings in FAISS
5. Search similar chunks
6. Build prompt with retrieved context
7. Ask OpenRouter LLM for the final answer

## Notes

The sample project uses a local embedding model (`all-MiniLM-L6-v2`) so you do not need a separate embedding API key.

The generation model is configured through `OPENROUTER_MODEL`. The default is `openrouter/free`. You can replace it with another model slug available in your OpenRouter account.

OpenRouter uses an OpenAI-compatible API endpoint, so the Python OpenAI client can be configured with OpenRouter's base URL.
